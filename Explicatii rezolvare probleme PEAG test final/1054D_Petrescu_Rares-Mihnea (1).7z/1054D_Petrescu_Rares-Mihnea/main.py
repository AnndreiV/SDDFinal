import numpy as np

def recombinare(populatie_parinti,pc):
    populatie_copii=populatie_parinti;
    return populatie_copii;
def mutatie(populatie_copii,pm):
    populatie_mutata=populatie_copii;
    return populatie_mutata;
def selectie(indivizi):
    parinti_selectati=indivizi;
    return parinti_selectati
def inlocuire(parinti,copii,X,a,b):
    generatia_urmatoare=parinti+copii
    for i in range(generatia_urmatoare):
        calitati_generatia_urmatoare=fitness(generatia_urmatoare[i],X,a,b)
    return generatia_urmatoare,calitati_generatia_urmatoare

def fitness(X,Z,a,b):

    scor=0

    for i in range(X):
        if(Z[i]==a*X[i]+b):
            scor+=1
    if(len(Z)!=len(X)):
        scor=0

    return scor


def generare(dim,X,Y,a,b):
    populatie_initiala=[]
    calitati_initiale=[]

    for i in range(dim):
        Z=np.random.permutation(Y)
        populatie_initiala+=[Z]
        calitati_initiale+=[fitness(X,Z,a,b)]

    return calitati_initiale,populatie_initiala

def GA(X,Y,a,b,dim,pm,pc,NMAX):
    it=0
    gata=0
    populatie_initiala,calitati_initiale=generare(dim,X,Y,a,b)
    counter=0
    maxim_istoric=np.max(calitati_initiale)
    scor_final=0
    populatie_finala=[]
    while it<NMAX and not gata:
        parinti=selectie(populatie_initiala)
        copii=recombinare(parinti,pc)
        copii_cu_mutatie=mutatie(copii,pm)
        populatie_inlocuita,calitati_noi=inlocuire(parinti,copii_cu_mutatie,X,a,b)
        maxim_nou=np.max(calitati_noi)
        minim_nou=np.min(calitati_noi)
        if maxim_nou>maxim_istoric:
            maxim_istoric=maxim_nou
            counter=0
        if maxim_nou==minim_nou:
            gata=1
        if(maxim_nou==len(Y)):
            gata=1
            scor_final=maxim_nou
            for i in range(calitati_noi):
                if(fitness(X,calitati_noi,a,b)==maxim_nou):
                    populatie_finala+=[calitati_noi]

        counter+=1
        it+=1
    return calitati_noi, scor_final



print( GA([3,6,9],[3,4,5],1,2,20,0.6,0.2,300))
